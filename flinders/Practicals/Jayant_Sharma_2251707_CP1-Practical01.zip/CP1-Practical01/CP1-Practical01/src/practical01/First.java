package practical01;

public class First {
    public static void main(String[] args) {
        int a = 6;
        int b = 7;
        int c = 3;
        int d = 5;
        System.out.println((b*a) + " = " + b + " * "+ a + " (answer 1)"); //example 1
        System.out.println(c +" + " + d + " = " + (c+d) + " (answer 2)"); // example 2


        System.out.println("\nThe ideas of \"state\" and \"sequence\" are");
        System.out.println("fundamental to most programming.");
    }
}
//method main
//class First

//In the program the integers are predefined. In example 1 the integers a & b are used. the program multiplies the
// integers and outputs its answer of 42, similarly in example 2 the integers c & d are added together to get a sum of 8
