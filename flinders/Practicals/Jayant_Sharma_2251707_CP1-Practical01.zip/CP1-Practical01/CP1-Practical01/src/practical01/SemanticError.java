package practical01;
//*******************************************************************
//   SemanticError.java   (Java Application)
//   Classes:  SemanticError
//*******************************************************************

class SemanticError {

   public static void main(String[] args) {
      System.out.println (6 + " is less than 10") ;
      System.out.println ("4 - 3 " + "equals 1") ;
      System.out.println ("Well" + " done") ;
   } // method main
}  // class SemanticError


