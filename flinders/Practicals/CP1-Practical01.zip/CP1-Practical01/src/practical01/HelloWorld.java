package practical01;

/*
 * Author: moon0016
 * File:   HelloWorld.java
 * Created on 15/02/2021, 10:55:25 AM
 */
public class HelloWorld {

    public static void main(String[] args) {

        System.out.println("Hello World");

    }
}
