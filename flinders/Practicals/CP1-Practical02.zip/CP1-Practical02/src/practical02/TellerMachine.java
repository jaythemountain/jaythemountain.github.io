package practical02;

import java.util.Scanner;

public class TellerMachine {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        // declare any variables here

        // Output the values here.

    }
}