package practical02;

public class Assignment {

    public static void main(String[] args) {
        // declare variables here
    }

}
