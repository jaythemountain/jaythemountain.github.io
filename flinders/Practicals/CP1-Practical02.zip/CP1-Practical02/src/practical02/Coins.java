package practical02;

import java.util.Scanner;

class Coins {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int num;

        System.out.print("Enter an amount of cents in the range 0 to 100: ");
        num = scan.nextInt();

        // Output goes here
    }
}
