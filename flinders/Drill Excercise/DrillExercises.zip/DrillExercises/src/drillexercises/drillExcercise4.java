package drillexercises;

import java.util.Scanner;

public class drillExcercise4 {
    Scanner scan = new Scanner(System.in);
//  1.
    //int A, B, C;
    //A = B;
  //  B= 8 ;

//  2.
    int digit = scan.nextInt();
    int score1, score2, score3;
    score1 = scan.nextInt()

//  3.
//  4.

}
