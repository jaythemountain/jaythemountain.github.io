package drillexercises;

//Write code which checks validity of a 5-digit positive integer entered by the user.
//The number is considered valid (true) if the first digit is less than the last digit.
//Otherwise it is invalid (false).
//87764
//Enter a 5-digit integer
//The number is false


import java.util.Scanner;

public class DrillExercise2 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

//        Q4
//        System.out.println("Enter a 5-digit integer");
//        int digit = scan.nextInt();
//        int first, last;
//
//        first = digit / 10000;
//        last = digit % 10;
//
//        if (first<last){
//            System.out.println("The number is true");
//        }
//        else{
//            System.out.println("The number is false");
//        }

//        Q1
//        System.out.println("Enter a 3-digit integer");
//        int digit = scan.nextInt();
//        int first, second, third;
//
//        first = digit / 100;
//        second = (digit / 10) % 10;
//        third = digit % 10;
//
//        if(first+second >= third){
//            System.out.println("The number is true");
//        }
//        else{
//            System.out.println("The number is false");
//        }

//        Q2
//        Write code that prints the phrase "People are Funny" on two lines, two words on the first line
//        System.out.println("People are \nFunny");

//        Q3
//        Write code that reads in a 4-digit number and that outputs the sum of the digits.
//        System.out.println("Enter a 4-digit integer");
//        int digit = scan.nextInt();
//        int first, second, third, fourth;
//
//        first = digit / 1000;
//        second = (digit / 100) % 10;
//        third = (digit / 10) % 10;
//        fourth = digit % 10;
//        int sum = first+second+third+fourth;
//
//        System.out.println("The sum of all of the digits is "+ sum);
    }
}
